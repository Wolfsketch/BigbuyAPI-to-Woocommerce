<?php
// Toon foutmeldingen
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Functie om de bestanden in een directory weer te geven
function listFiles($dir) {
    if (is_dir($dir)) {
        echo "Inhoud van directory: $dir\n";
        $files = scandir($dir);
        foreach ($files as $file) {
            if ($file !== '.' && $file !== '..') {
                echo "$file\n";
            }
        }
    } else {
        echo "Directory bestaat niet: $dir\n";
    }
}

// Controleer de inhoud van de vendor-directory
listFiles(__DIR__ . '/vendor');

// Controleer de inhoud van de swagger-client-directory
listFiles(__DIR__ . '/vendor/swagger-client');

// Controleer de inhoud van de Client-directory
listFiles(__DIR__ . '/vendor/swagger-client/src/Client/Api');

?>