<?php
require __DIR__ . '/vendor/autoload.php';

$loader = new \Composer\Autoload\ClassLoader();
$namespaces = $loader->getPrefixesPsr4();

echo '<pre>';
print_r($namespaces);
echo '</pre>';
?>