<?php

putenv('HOME=/home/f6pw76hthyoq');
putenv('COMPOSER_HOME=/home/f6pw76hthyoq/.composer');

if (!isset($_GET['command'])) {
    echo "Geef een Composer opdracht op via de 'command' query parameter.";
    exit;
}

$command = escapeshellcmd($_GET['command']);
$dir = __DIR__;

$output = shell_exec("cd {$dir} && php composer.phar {$command} 2>&1");
if ($output === null) {
    echo "Er is een fout opgetreden. Controleer het logbestand voor details.";
} else {
    echo nl2br(htmlentities($output));
}
?>