<?php
putenv('COMPOSER_HOME=' . __DIR__ . '/.composer');
$composerPath = __DIR__ . '/composer.phar';
$command = 'php ' . $composerPath . ' dump-autoload';

exec($command, $output, $return_var);
echo 'Uitvoer: ' . implode("\n", $output);
echo "\nReturn waarde: " . $return_var;
?>
