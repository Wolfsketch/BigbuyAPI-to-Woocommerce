<?php
putenv('COMPOSER_HOME=' . __DIR__ . '/.composer');
$composerPath = __DIR__ . '/composer.phar';
$command = 'php ' . $composerPath . ' update 2>&1';  // Voeg 2>&1 toe om foutmeldingen vast te leggen

exec($command, $output, $return_var);
echo 'Uitvoer: ' . implode("\n", $output);
echo "\nReturn waarde: " . $return_var;
?>