<?php
// Toon foutmeldingen
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once('config.php');

use GuzzleHttp\Client;

function checkRateLimit($client) {
    try {
        $response = $client->get("catalog/products.json?isoCode=nl&limit=1");
        $rateLimit = $response->getHeader('X-RateLimit-Limit')[0];
        $rateRemaining = $response->getHeader('X-RateLimit-Remaining')[0];
        $rateReset = $response->getHeader('X-RateLimit-Reset')[0];
        
        echo "Rate Limit: $rateLimit\n";
        echo "Rate Remaining: $rateRemaining\n";
        echo "Rate Reset: $rateReset\n";
    } catch (Exception $e) {
        echo 'Exception when calling BigBuy API: ', $e->getMessage(), PHP_EOL;
    }
}

// Maak een BigBuy client aan
$bigBuyClient = getBigBuyClient();

// Controleer de rate limit
checkRateLimit($bigBuyClient);

?>
