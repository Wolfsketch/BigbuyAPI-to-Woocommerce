<?php

require __DIR__ . '/vendor/autoload.php';

use GuzzleHttp\Client;

// Functie om een BigBuy API-client te maken
function getBigBuyClient() {
    return new Client([
        'base_uri' => 'https://api.bigbuy.eu/rest/',
        'headers' => [
            'Authorization' => 'Bearer ZjEyMmNlNWFhYmI0ZGMwYjlmNmRiYjRkYzNmYTg0NjYwOGI2OTZkOGU0Yzk0NWMwZWY1ZDUxMDM3MjRlNjgwZg',
            'Accept'        => 'application/json',
        ],
    ]);
}

?>